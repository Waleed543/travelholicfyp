<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class rooms_facilities extends Model
{
    protected $table = 'rooms_facilities';

    protected $guarded = [];
}
