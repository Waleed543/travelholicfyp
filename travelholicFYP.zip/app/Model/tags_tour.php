<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class tags_tour extends Model
{
    protected $table = 'tags_tour';

    protected $guarded = [];
}
