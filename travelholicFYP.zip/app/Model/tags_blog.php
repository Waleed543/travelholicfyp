<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class tags_blog extends Model
{
    protected $table = 'tags_blog';

    protected $guarded = [];


}
