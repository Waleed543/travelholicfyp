<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class book_hotel extends Model
{
    protected $table = 'book_hotel';

    protected $guarded = [];
}
