<?php $__env->startSection('nav','fixed-top'); ?>
<?php $__env->startSection('content'); ?>
    <div class="landing">
        <div class="home-wrap">
            <div class="home-inner" style="background-image: url('<?php echo e(asset('img/bg_1.jpg')); ?>')">
            </div>
        </div>
    </div>
    <div class="caption text-center">
        <h1>Welcome To TravelHolic</h1>
        <h3>Book Your Tour With Us</h3>
        <a class="btn btn-outline-light btn-lg" href="#course">Book Tours</a>
    </div>

    <div class="jumbotron">
        <div class="text-center">
            <div class="col-12">
                <h3 class="heading">DahsBoard</h3>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <nav class="dashboard-nav navbar navbar-expand-md navbar-dark bg-dark">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive1">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarResponsive1">
                            <ul class="navbar-nav float-left">
                                <li class="nav-item">
                                    <a class="nav-link" href="#home">My Profile</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#course">My Tours</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#features">Features</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#clients">Clients</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#contact">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>


    <?php echo $__env->yieldContent('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelholicFYP\resources\views/user/dashboard/layout/app.blade.php ENDPATH**/ ?>