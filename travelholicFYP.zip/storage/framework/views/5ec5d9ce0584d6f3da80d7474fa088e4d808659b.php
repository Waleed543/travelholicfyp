<?php $__env->startSection('title', 'Tour Setting'); ?>
<?php $__env->startSection('tour','current'); ?>
<?php $__env->startSection('headerName', 'Tour Setting'); ?>
<?php $__env->startSection('content'); ?>

    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3">
                        <div class="col-xl-3 col-sm-6 p-2">
                            <div class="card">
                                <a href="<?php echo e(route('admin.dashboard.tour.setting.tag')); ?>">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between">
                                            <i class="fas fa-users fa-3x text-info"></i>
                                            <div class="text-right text-secondary">
                                                <h5>List all</h5>
                                                <h3>Tags</h3>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <a href="<?php echo e(route('admin.dashboard.tour.setting.create.tag')); ?>">
                                    <div class="card-footer text-secondary">
                                        <i class="fas fa-sync mr-3"></i>
                                        <span>Add New Tag</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <?php echo $__env->yieldContent('setting_content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboardAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelholicFYP\resources\views/admin/dashboard/tour/setting/app.blade.php ENDPATH**/ ?>