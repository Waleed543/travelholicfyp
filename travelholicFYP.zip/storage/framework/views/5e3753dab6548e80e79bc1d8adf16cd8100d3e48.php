<?php $__env->startSection('nav','fixed-top'); ?>
<?php $__env->startSection('css-files'); ?>
    <link href="<?php echo e(asset('css/blog-single.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="landing">
        <div class="home-wrap">
            <div class="home-inner" style="background-image: url('<?php echo e(asset('img/blog.jpg')); ?>')">
            </div>
        </div>
    </div>
    <div class="caption text-center">
        <h1>Room Type</h1>
        <h3>Check Details for this room type</h3>
        <a class="btn btn-outline-light btn-lg" href="#course">Create Hotel</a>
    </div>
    <!--- Start Courese Section -->
    <div class="jumbotron">
        <div class="narrow text-center">

        </div><!--- End Narrow Section -->
    </div>
    <!--- Start Courese Section -->
    <!--- Start Blog Section -->
    <div class="container-fluid">
        <div class="container">
            <div class="row welcome text-center">
                <div class="col-12">
                    <h1 class="display-4">Room Type</h1>
                </div>
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-8">
                <div class="page-wrapper">
                    <div class="blog-title-area">
                        <div class="card blog-body" style="margin-left: 0">
                            <h3 class="search card-header white-text text-center py-4"> Room Type Name</h3>
                            <div class="card-body">
                                <div class="single-post-media">
                                    <img class="img-fluid" style="height :400px; width: 1000px;" src="<?php echo e(asset('storage/'.$hotel->user->username.'/hotel/room/'.$room->thumbnail)); ?>">
                                </div>
                                <br>
                                <div class="blog-content text-justify text-dark" style="max-width: 10000px" id="blog_content">
                                    <div class="row">

                                        <div  class="col-md-12" style="padding: 0">
                                            <div  class="card" style="margin-left: 0">
                                                <div class="card-header" style="background-color: black; color: white">
                                                    <strong class="card-title">Type Information</strong>
                                                </div>
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p class="card-text">Available Rooms : <?php echo e($room->available); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p class="card-text">Price : <?php echo e($room->price); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p class="card-text">Total Rooms : <?php echo e($room->total); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p class="card-text">Hotel Name : <?php echo e($hotel->name); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p class="card-text">Created on : <?php echo e($room->created_at); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p class="card-text">Last updated : <?php echo e($room->updated_at); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div  class="col-md-12" style="padding: 0; padding-top: 15px">
                                            <div  class="card" style="margin-left: 0">
                                                <div class="card-header" style="background-color: black; color: white">
                                                    <strong class="card-title">Description</strong>
                                                </div>
                                                <div class="card-body">
                                                    <?php echo e($room->description); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div  class="col-md-12" style="padding: 0; padding-top: 15px">
                                            <div  class="card" style="margin-left: 0">
                                                <div class="card-header" style="background-color: black; color: white">
                                                    <strong class="card-title">Facilities</strong>
                                                </div>
                                                <div class="card-body">
                                                    <span class="badge badge-success">Included</span>
                                                    <p>
                                                        <?php if($facilities != null): ?>
                                                            <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                -<?php echo e($facility->name); ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>



                                    </div>
                                </div><!-- end content -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card writer">
                    <!--Card content-->
                    <img src="<?php echo e(asset('storage/'.$hotel->user->username.'/profile_image/'.$hotel->user->profile->image)); ?>" alt="John" style="width:100%">
                    <br>
                    <h1><?php echo e($hotel->user->name); ?></h1>
                    <p class="title">CEO & Founder, Example</p>
                    <p>Harvard University</p>
                    
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
    <!--- End Blog Section -->
    <script src="<?php echo e(asset('js/blog-single.js')); ?>" type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            $("#myCarousel").on("slide.bs.carousel", function(e) {
                var $e = $(e.relatedTarget);
                var idx = $e.index();
                var itemsPerSlide = 3;
                var totalItems = $(".carousel-item").length;

                if (idx >= totalItems - (itemsPerSlide - 1)) {
                    var it = itemsPerSlide - (totalItems - idx);
                    for (var i = 0; i < it; i++) {
                        // append slides to end
                        if (e.direction == "left") {
                            $(".carousel-item")
                                .eq(i)
                                .appendTo(".carousel-inner");
                        } else {
                            $(".carousel-item")
                                .eq(0)
                                .appendTo($(this).find(".carousel-inner"));
                        }
                    }
                }
            });
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/hotel/rooms/show.blade.php ENDPATH**/ ?>