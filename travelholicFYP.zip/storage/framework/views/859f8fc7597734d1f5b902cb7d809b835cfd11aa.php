<nav class="navbar navbar-expand-md navbar-dark bg-dark <?php echo $__env->yieldContent('nav'); ?>">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logowhite.png')); ?>"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav float-left">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('blog.index')); ?>">Blog</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('tour.index')); ?>">Tour</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('hotel.index')); ?>">Hotel</a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('contactus')); ?>">Contact</a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('admin')); ?>">
                                <?php echo e('Dashboard'); ?>

                            </a>
                        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notAdmin')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">
                                <?php echo e('Dashboard'); ?>

                            </a>
                        <?php endif; ?>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/inc/header.blade.php ENDPATH**/ ?>