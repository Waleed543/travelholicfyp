<?php $__env->startSection('title','Users Setting'); ?>
<?php $__env->startSection('user','current'); ?>
<?php $__env->startSection('headerName', 'Users'); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3 mb-5">
                        <div class="col-md-4 col-xl-12">
                            <h3 class="text-muted text-center mb-3">Search</h3>
                            <table class="table table-responsive table-dark table-hover text-center">
                                <thead>
                                <tr class="">
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Email Verified</th>
                                    <th>Created_at</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($users) > 0): ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($loop->iteration); ?></th>
                                            <td style="<?php echo e($user->deleted_at ? 'background-color:red;' :''); ?>"><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->username); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($user->email_verified_at ? $user->email_verified_at :'No'); ?></td>
                                            <td><?php echo e($user->created_at); ?></td>

                                            <td>
                                                <div class="d-inline" role="group">
                                                    
                                                    <a type="button" href="" class="btn btn-success btn-sm"
                                                        onclick="event.preventDefault();
                                                        document.getElementById('edit-user-<?php echo e($loop->iteration); ?>').submit();">
                                                        Edit
                                                    </a>
                                                    <form id="edit-user-<?php echo e($loop->iteration); ?>" action="<?php echo e(route('admin.dashboard.user.edit',$user->username)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('GET'); ?>
                                                    </form>
                                                    
                                                    <a type="button" href="" class="btn btn-danger btn-sm"
                                                       onclick="event.preventDefault();
                                                        document.getElementById('delete-user-<?php echo e($loop->iteration); ?>').submit();">
                                                        <?php echo e($user->deleted_at ? 'Permanent ' :''); ?> Delete
                                                    </a>
                                                    <form id="delete-user-<?php echo e($loop->iteration); ?>" action="<?php echo e(route('admin.dashboard.user.delete',$user->username)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('GET'); ?>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- pagination -->
                            <nav>
                                <ul class="pagination justify-content-center">
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            <span>Previous</span>
                                        </a>
                                    </li>
                                    <li class="page-item active">
                                        <a href="#" class="page-link py-2 px-3">
                                            1
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            2
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            3
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            <span>Next</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                            <!-- end of pagination -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of tables -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboardAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/admin/dashboard/user/index.blade.php ENDPATH**/ ?>