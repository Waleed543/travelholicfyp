<?php $__env->startSection('title','Tour Book'); ?>
<?php $__env->startSection('booking','current'); ?>
<?php $__env->startSection('headerName', 'Booking'); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3 mb-5">
                        <div class="col-xl-12 col-12">
                            <h3 class="text-muted text-center mb-3">My Bookings</h3>
                            <table class="table table-dark table-hover text-center">
                                <thead>
                                <tr class="">
                                    <th>#</th>
                                    <th>Seats</th>
                                    <th>Adults</th>
                                    <th>Children</th>
                                    <th>Phone</th>
                                    <th>Status</th>
                                    <th>Payment Type</th>
                                    <th>Payment Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($bookings) > 0): ?>
                                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($booking->seats); ?></td>
                                            <td><?php echo e($booking->adults); ?></td>
                                            <td><?php echo e($booking->children); ?></td>
                                            <td><?php echo e($booking->phone); ?></td>
                                            <td>
                                                <?php if($booking->status == \App\Enums\BookingStatus::Reserved): ?>
                                                    <span class="badge badge-danger w-75 py-2">Reserved</span>
                                                <?php elseif($booking->status == \App\Enums\BookingStatus::Booked): ?>
                                                    <span class="badge badge-success w-75 py-2">Booked</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($booking->payment_type); ?></td>
                                            <td>
                                                <?php if($booking->payment_status == \App\Enums\PaymentStatus::Unpaid): ?>
                                                    <span class="badge badge-danger w-75 py-2">Unpaid</span>
                                                <?php elseif($booking->payment_status == \App\Enums\PaymentStatus::UnderReview): ?>
                                                    <span class="badge badge-warning w-75 py-2">Under Review</span>
                                                <?php elseif($booking->payment_status == \App\Enums\PaymentStatus::Successful): ?>
                                                    <span class="badge badge-success w-75 py-2">Successful</span>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <div class="d-inline" role="group">
                                                     
                                                    <a type="button" href="" class="btn btn-danger btn-sm"
                                                       onclick="event.preventDefault();
                                                           document.getElementById('delete-tour-<?php echo e($loop->iteration); ?>').submit();">
                                                        Delete
                                                    </a>
                                                    <form id="delete-tour-<?php echo e($loop->iteration); ?>" action="<?php echo e(route('dashboard.tour.book.delete',$booking->number)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- pagination -->
                            <nav>
                                <ul class="pagination justify-content-center">
                                    <?php echo e($bookings->links()); ?>

                                </ul>
                            </nav>
                            <!-- end of pagination -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of tables -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/user/dashboard/booking/tour.blade.php ENDPATH**/ ?>