<?php $__env->startSection('title','My Blogs'); ?>
<?php $__env->startSection('blog','current'); ?>
<?php $__env->startSection('headerName', 'Blog'); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3">
                        <div class="col-md-12 search-card">
                            <!-- Material form contact -->
                            <div class="card search">
                                <!--Card content-->
                                <div class="card-body px-lg-5 pt-0">
                                    <div class="text-center">
                                        <a class="mt-3 btn btn-light" href="#searchs" data-toggle="collapse">Search</a>
                                    </div>
                                    <div id="searchs" class="collapse">
                                        <hr>
                                        <form  id="search" method="GET" action="<?php echo e(route('dashboard.blog.search')); ?>" enctype="multipart/form-data" class="form-horizontal">
                                            
                                            <div class="row form-group">
                                                <div class="col-12 col-md-12">
                                                    <label for="name" class=" form-control-label">Name</label>
                                                    <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            
                                            <div class="row form-group">
                                                <div class="col-12 col-md-6">
                                                    <label for="category_id" class=" form-control-label">Category</label>
                                                    <select name="category_id" id="select" class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <option value="">Select</option>
                                                        <?php if(count($categories)>0): ?>
                                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(old('category_id') == $category->id): ?>
                                                                    <option selected value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                    <?php $__errorArgs = ['departure_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-secondary btn-sm" value="submit" form="search">
                                                Search
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Material form contact -->
                        </div>
                    </div>
                </div>
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row mb-5">
                        <div class="col-xl-12 col-12">
                            <h3 class="text-muted text-center mb-3">My Blogs</h3>
                            <table class="table table-dark table-hover text-center">
                                <thead>
                                <tr class="">
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Slug</th>
                                    <th>Created at</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($blogs) > 0): ?>
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($blog->title); ?></td>
                                            <td><?php echo e($blog->slug); ?></td>
                                            <td><?php echo e($blog->created_at); ?></td>
                                            <td>
                                                <?php if($blog->status == \App\Enums\Status::Active): ?>
                                                    <span class="badge badge-success w-75 py-2">Active</span>
                                                <?php elseif($blog->status == \App\Enums\Status::InProgress): ?>
                                                    <span class="badge badge-warning w-75 py-2">In progress</span>
                                                <?php elseif($blog->status == \App\Enums\Status::InActive): ?>
                                                    <span class="badge badge-danger w-75 py-2">InActive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="d-inline" role="group">
                                                    
                                                    <a type="button" href="" class="btn btn-success btn-sm"
                                                       onclick="event.preventDefault();
                                                           document.getElementById('edit-blog-<?php echo e($loop->iteration); ?>').submit();">
                                                        Edit
                                                    </a>
                                                    <form id="edit-blog-<?php echo e($loop->iteration); ?>" action="<?php echo e(route('dashboard.blog.edit',$blog->slug)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('GET'); ?>
                                                    </form>
                                                    
                                                    <a type="button" href="" class="btn btn-danger btn-sm"
                                                       onclick="event.preventDefault();
                                                           document.getElementById('delete-blog-<?php echo e($loop->iteration); ?>').submit();">
                                                       Delete
                                                    </a>
                                                    <form id="delete-blog-<?php echo e($loop->iteration); ?>" action="<?php echo e(route('dashboard.blog.delete',$blog->slug)); ?>" method="POST" style="display: none;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- pagination -->
                            <nav>
                                <ul class="pagination justify-content-center">
                                    <?php echo e($blogs->links()); ?>

                                </ul>
                            </nav>
                            <!-- end of pagination -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of tables -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/user/dashboard/blog/index.blade.php ENDPATH**/ ?>