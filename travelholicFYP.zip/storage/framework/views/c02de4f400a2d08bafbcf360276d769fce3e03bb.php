<?php $__env->startSection('title','Tour Profile'); ?>
<?php $__env->startSection('tour','current'); ?>
<?php $__env->startSection('headerName', 'Tour Profile'); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3 mb-5">
                        <div class="col-md-10">
                            <div class="card">
                                <div class="card-header">
                                    <strong>Update Profile</strong>
                                </div>
                                <div class="card-body card-block">
                                    <form  id="update" method="post" action="<?php echo e(route('tour.profile.store',$tour->slug)); ?>" enctype="multipart/form-data" class="form-horizontal">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="row form-group">
                                            <?php if(count($tour_days)>0): ?>
                                                <?php $__currentLoopData = $tour_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-lg-12">
                                                        <label for="day-<?php echo e($day->number); ?>" class=" form-control-label"><h3>Day <?php echo e($day->number); ?></h3></label>
                                                        <textarea class="form-control" name="day-<?php echo e($day->number); ?>" rows="3"><?php echo e($day->description); ?></textarea>
                                                        <?php $__errorArgs = ["day-<?php echo e($day->number); ?>"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php for($i = 1; $i <= $tour->days; $i++): ?>
                                                    <div class="col-lg-12">
                                                        <label for="day-<?php echo e($i); ?>" class=" form-control-label"><h3>Day <?php echo e($i); ?></h3></label>
                                                        <textarea class="form-control" name="day-<?php echo e($i); ?>" rows="3"></textarea>
                                                        <?php $__errorArgs = ["day-<?php echo e($i); ?>"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                <?php endfor; ?>
                                            <?php endif; ?>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary btn-sm" value="submit" form="update">
                                        Update
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    
    

    
    
    
    
    
    

    
    
    
    


    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelholicFYP\resources\views/user/dashboard/tour/profile.blade.php ENDPATH**/ ?>