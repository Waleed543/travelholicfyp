<footer>
    <div class="row justify-content-center">

        <div class="col-md-5 text-center">
            <img src="<?php echo e(asset('img/logowhite.png')); ?>" style="height: 70px">
            <p></p>
            <strong>Contact Info</strong>
            <p>0316-0752005<br>bilalaijaz.88@gmail.com</p>
            <a href="#" target="_blank"><i class="fab fa-facebook-square"></i></a>
            <a href="#" target="_blank"><i class="fab fa-twitter-square"></i></a>
            <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
        </div>

        <hr class="socket">
        &copy; TravelHolic.

    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\travelholicFYP\resources\views/inc/footer.blade.php ENDPATH**/ ?>