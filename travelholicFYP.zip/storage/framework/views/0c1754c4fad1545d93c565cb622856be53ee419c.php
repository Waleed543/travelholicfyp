<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://use.fontawesome.com/releases/v5.5.0/js/all.js"></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="/css/dashboard.css">

    <?php echo $__env->yieldContent('css'); ?>

    <title>Admin-<?php echo $__env->yieldContent('title'); ?></title>
</head>
<body onload="submit_button()">
<?php echo $__env->make('inc.message_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- navbar -->
<?php echo $__env->make('admin.inc.dashboardAdminNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end of navbar -->

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('js'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
<script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
</body>
</html>






<?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/admin/layouts/dashboardAdmin.blade.php ENDPATH**/ ?>