<?php $__env->startSection('background_image'); ?>
    <div class="home-inner" style="background-image: url('<?php echo e(asset('img/bg_1.jpg')); ?>')">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('caption'); ?>
    <h1>Welcome To TravelHolic</h1>
    <h3>Book Your Tour With Us</h3>
    <a class="btn btn-outline-light btn-lg" href="#course">Book Tours</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelholicFYP\resources\views/temp.blade.php ENDPATH**/ ?>