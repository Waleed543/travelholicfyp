<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>TravelHlolic <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Styles -->
    <!-- Material Design Bootstrap -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script type="text/javascript"
            src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>
    <?php echo $__env->yieldContent('css-files'); ?>
</head>

<body>

    <!-- Navigation -->
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navigation -->

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--- End Contact Section -->


<!--- Script Source Files -->
    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>

    <script src="https://kit.fontawesome.com/15ce08dfb5.js" crossorigin="anonymous"></script>
    <!-- MDB core JavaScript -->
<!--- End of Script Source Files -->

</body>
</html>
<?php /**PATH C:\xampp\htdocs\travelholicFYP\resources\views/layouts/app.blade.php ENDPATH**/ ?>