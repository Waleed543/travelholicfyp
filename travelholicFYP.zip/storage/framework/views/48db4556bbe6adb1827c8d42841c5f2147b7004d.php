<?php $__env->startSection('nav','fixed-top'); ?>
<?php $__env->startSection('css-files'); ?>
    <link href="<?php echo e(asset('css/blog-single.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="landing">
        <div class="home-wrap">
            <div class="home-inner" style="background-image: url('<?php echo e(asset('img/blog.jpg')); ?>')">
            </div>
        </div>
    </div>
    <div class="caption text-center">
        <h1>Hotels</h1>
        <h3>Check Our Deals for hotels</h3>
        <a class="btn btn-outline-light btn-lg" href="#course">Create Hotel</a>
    </div>
    <!--- Start Courese Section -->
    <div class="jumbotron">
        <div class="narrow text-center">

        </div><!--- End Narrow Section -->
    </div>
    <!--- Start Courese Section -->
    <!--- Start Blog Section -->
    <div class="container-fluid">
        <div class="container">
            <div class="row welcome text-center">
                <div class="col-12">
                    <h1 class="display-4">Hotel</h1>
                </div>
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-8">
                <div class="page-wrapper">
                    <div class="blog-title-area">
                        <div class="card blog-body" style="margin-left: 0">
                            <h3 class="search card-header white-text text-center py-4"><?php echo e($hotel->name); ?></h3>
                            <div class="card-body">
                                <div class="single-post-media">
                                    <img class="img-fluid" style="height :400px; width: 1000px;" src="<?php echo e(asset('storage/'.$hotel->user->username.'/hotel/'.$hotel->thumbnail)); ?>">
                                </div>
                                <br>
                                <div class="blog-content text-justify text-dark" style="max-width: 10000px" id="blog_content">
                                    <div class="row">

                                        <div  class="col-md-12" style="padding: 0">
                                            <div  class="card" style="margin-left: 0">
                                                <div class="card-header" style="background-color: black; color: white">
                                                    <strong class="card-title">Hotel Information</strong>
                                                </div>
                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p class="card-text">Available Rooms : <?php echo e($hotel->available_rooms); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p class="card-text">City : <?php echo e(App\City::find($hotel->city)->name); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p class="card-text">Total Rooms : <?php echo e($hotel->total_rooms); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p class="card-text">Status : <?php echo e($hotel->status); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p class="card-text">Created on : <?php echo e($hotel->created_at); ?></p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p class="card-text">Last updated : <?php echo e($hotel->updated_at); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div  class="col-md-12" style="padding: 0; padding-top: 15px">
                                            <div  class="card" style="margin-left: 0">
                                                <div class="card-header" style="background-color: black; color: white">
                                                    <strong class="card-title">Description</strong>
                                                </div>
                                                <div class="card-body">
                                                    <?php echo $hotel->description; ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div  class="col-md-12" style="padding: 0; padding-top: 15px">
                                            <div  class="card" style="margin-left: 0">
                                                <div class="card-header" style="background-color: black">
                                                    <strong class="card-title" style="color: white">Rooms</strong>
                                                </div>
                                                <div class="card-body">
                                                    <?php if(count($rooms) != 0): ?>
                                                                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                                                    <div class="carousel-inner">
                                                                        <div class="carousel-item active">
                                                                            <div class="row">
                                                                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <div class="card col-md-3" style="margin-left: 3.5rem">
                                                                                        <div class="card-header" style="background-color: grey;">
                                                                                            <strong class="card-title"><?php echo e($room->name); ?></strong>
                                                                                        </div>
                                                                                        <div class="card-body">
                                                                                            <img class="img-fluid" src="<?php echo e(asset('storage/'.$hotel->user->username.'/hotel/room/'.$room->thumbnail)); ?>">
                                                                                        </div>
                                                                                        <div class="card-footer">
                                                                                            <div class="row">
                                                                                                <h5>Price : <?php echo e($room->price); ?></h5>
                                                                                                <a class="btn btn-sm btn-primary ml-auto" href="<?php echo e(route('room.show',[$hotel->slug,$room->slug])); ?>">Show Now</a>
                                                                                                <a target="_blank" class="btn bnt-sm btn-outline-primary"
                                                                                                   onclick="document.getElementById('book-<?php echo e($room->slug); ?>').submit();">
                                                                                                    Book
                                                                                                </a>
                                                                                                <form id="book-<?php echo e($room->slug); ?>" method="POST" action="<?php echo e(route('dashboard.hotel.book',[$hotel->slug,$room->slug])); ?>" class="d-none">
                                                                                                    <?php echo csrf_field(); ?>
                                                                                                    <?php echo method_field('GET'); ?>
                                                                                                </form>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                                                        <i class="fa fa-chevron-circle-left fa-2x" aria-hidden="true" style="color: black"></i>
                                                                        <span class="sr-only">Previous</span>
                                                                    </a>
                                                                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                                                        <i class="fa fa-chevron-circle-right fa-2x" aria-hidden="true" style="color: black"></i>
                                                                        <span class="sr-only">Next</span>
                                                                    </a>
                                                                </div>
                                                    <?php else: ?>
                                                        No Room Type Found
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div><!-- end content -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card writer">
                    <!--Card content-->
                    <img src="<?php echo e(asset('storage/'.$hotel->user->username.'/profile_image/'.$hotel->user->profile->image)); ?>" alt="John" style="width:100%">
                    <br>
                    <h1><?php echo e($hotel->user->name); ?></h1>
                    <p class="title">CEO & Founder, Example</p>
                    <p>Harvard University</p>
                    
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
    <!--- End Blog Section -->
    <script src="<?php echo e(asset('js/blog-single.js')); ?>" type="text/javascript"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/hotel/show.blade.php ENDPATH**/ ?>