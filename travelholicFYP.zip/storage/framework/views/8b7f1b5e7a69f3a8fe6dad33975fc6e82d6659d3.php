<?php $__env->startSection('title','My Rooms'); ?>
<?php $__env->startSection('hotel','current'); ?>
<?php $__env->startSection('headerName', 'Hotel'); ?>
<?php $__env->startSection('content'); ?>

    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3">
                        <div class="col-xl-3 col-sm-6 p-2">
                            <div class="card">
                                <a href="">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between">
                                            <i class="fas fa-users fa-3x text-info"></i>
                                            <div class="text-right text-secondary">
                                                <h5>Total Rooms Type = <?php echo e(count($rooms)); ?></h5>
                                                <h3>Rooms</h3>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <a href="<?php echo e(route('dashboard.hotel.room.create',$slug)); ?>">
                                    <div class="card-footer text-secondary">
                                        <i class="fas fa-sync mr-3"></i>
                                        <span>Add New Room Type</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                <div class="row">
                    <div class="col-xl-12 col-12">
                        <h3 class="text-muted text-center mb-3">All Rooms</h3>
                        <table class="table table-dark table-hover text-center">
                            <thead>
                            <tr class="">
                                <th>#</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Created at</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($rooms) > 0): ?>
                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($room->name); ?></td>
                                        <td><?php echo e($room->slug); ?></td>
                                        <td><?php echo e($room->created_at); ?></td>
                                        <td>
                                            <div class="d-inline" role="group">
                                                
                                                <a type="button" href="" class="btn btn-success btn-sm"
                                                   onclick="event.preventDefault();
                                                       document.getElementById('edit-hotel-<?php echo e($loop->iteration); ?>').submit();">
                                                    Edit
                                                </a>
                                                <form id="edit-hotel-<?php echo e($loop->iteration); ?>" action="<?php echo e(route('dashboard.hotel.room.edit',[$slug,$room->slug])); ?>" method="POST" style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('GET'); ?>
                                                </form>
                                                
                                                <a type="button" href="" class="btn btn-danger btn-sm"
                                                   onclick="event.preventDefault();
                                                       document.getElementById('delete-tour-<?php echo e($loop->iteration); ?>').submit();">
                                                    Delete
                                                </a>
                                                <form id="delete-tour-<?php echo e($loop->iteration); ?>" action="<?php echo e(route('room.destroy',[$slug,$room->slug])); ?>" method="POST" style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- pagination -->
                        <nav>
                            <ul class="pagination justify-content-center">
                                <li class="page-item">
                                    <a href="#" class="page-link py-2 px-3">
                                        <span>Previous</span>
                                    </a>
                                </li>
                                <li class="page-item active">
                                    <a href="#" class="page-link py-2 px-3">
                                        1
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a href="#" class="page-link py-2 px-3">
                                        2
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a href="#" class="page-link py-2 px-3">
                                        3
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a href="#" class="page-link py-2 px-3">
                                        <span>Next</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                        <!-- end of pagination -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of tables -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sun Fiber\Desktop\Bilal\University\htdocs\travelholicFYP\resources\views/user/dashboard/hotel/room/index.blade.php ENDPATH**/ ?>