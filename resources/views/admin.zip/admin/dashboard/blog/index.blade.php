@extends('admin.layouts.dashboardAdmin')
@section('blog','current')
@section('headerName', 'Blogs')
@section('search-bar')
    <div class="search-bar">
        <form>
            <div class="input-group">
                <input type="text" class="form-control search-input" placeholder="Search...">
                <button type="button" class="btn btn-white search-button"><i class="fas fa-search text-danger"></i></button>
            </div>
        </form>
    </div>
@endsection
@section('content')
    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row pt-md-5 mt-md-3 mb-5">
                        <div class="col-xl-12 col-12">
                            <h3 class="text-muted text-center mb-3">Search</h3>
                            <table class="table table-dark table-hover text-center">
                                <thead>
                                <tr class="">
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Slug</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th>1</th>
                                    <td>Monica</td>
                                    <td>$2000</td>
                                    <td>25/05/2018</td>
                                    <td><span class="badge badge-success w-75 py-2">Approved</span></td>
                                </tr>
                                <tr>
                                    <th>2</th>
                                    <td>Nick</td>
                                    <td>$2000</td>
                                    <td>25/05/2018</td>
                                    <td><span class="badge badge-success w-75 py-2">Approved</span></td>
                                </tr>
                                <tr>
                                    <th>3</th>
                                    <td>Alex</td>
                                    <td>$2000</td>
                                    <td>25/05/2018</td>
                                    <td><span class="badge badge-danger w-75 py-2">Pending</span></td>
                                </tr>
                                <tr>
                                    <th>4</th>
                                    <td>Jane</td>
                                    <td>$2000</td>
                                    <td>25/05/2018</td>
                                    <td><span class="badge badge-danger w-75 py-2">Pending</span></td>
                                </tr>
                                <tr>
                                    <th>5</th>
                                    <td>Michael</td>
                                    <td>$2000</td>
                                    <td>25/05/2018</td>
                                    <td><span class="badge badge-success w-75 py-2">Approved</span></td>
                                </tr>
                                <tr>
                                    <th>6</th>
                                    <td>Kate</td>
                                    <td>$2000</td>
                                    <td>25/05/2018</td>
                                    <td><span class="badge badge-danger w-75 py-2">Pending</span></td>
                                </tr>
                                </tbody>
                            </table>
                            <!-- pagination -->
                            <nav>
                                <ul class="pagination justify-content-center">
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            <span>Previous</span>
                                        </a>
                                    </li>
                                    <li class="page-item active">
                                        <a href="#" class="page-link py-2 px-3">
                                            1
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            2
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            3
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a href="#" class="page-link py-2 px-3">
                                            <span>Next</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                            <!-- end of pagination -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of tables -->

@endsection
